/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package airport;

/**
 *
 * @author MiguelAngel
 */

public class Aeropuerto {

    /**
     */

    /* Proximos pasos para la práctica:
     * Falta darle vida al aeropuerto, ejemplo:
     * bucle que itere y en cada iteracion pasen cosas, como
     * que los aviones avancen (cambien de posicion) y al llegar
     * a una en concreto aterricen, y la pista va diciendo si 
     * hay algun avion en ella.
     */

    
    public static void main(int shaderProgr, int uniModel) {
       
       Dibujable dibujables[] = new Dibujable[10];
       
       Fondo miPaisaje = new Fondo();
       dibujables[0] = miPaisaje;
       Pista pistaMain = new Pista();
       dibujables[1] = pistaMain;
       Pista pista2 = new Pista();
       Torre torreControl = new Torre();
       dibujables[2] = torreControl;
       Avion miBoeing1 = new Avion(0.4f, -0.8f, 0f);

       dibujables[3] = miBoeing1;
       miBoeing1.Draw(shaderProgr, uniModel);
       //Dibujamos los elementos
       //
       //for(int dex = 0; dex <= 7; dex++){
       //    dibujables[dex].Draw(int shaderProgram);
       //}
       
       //Interactuamos con ellos
       
       
       /*miPaisaje.AddElements();
       miPaisaje.WeatherNow();
       torreControl.Altura();
       torreControl.Connect();
       
       pistaMain.LongPista();
       pistaMain.EsPrincipal("Principal");
       */	       

    }

    
}
