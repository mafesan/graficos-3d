varying vec4  vFinalColor;
 
void main(void)  {
	gl_FragColor = vFinalColor;
}